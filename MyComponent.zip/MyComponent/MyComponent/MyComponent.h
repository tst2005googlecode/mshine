#ifndef _MY_COMPONENT_H_
#define _MY_COMPONENT_H_
#include "IMyComponent.h"

#define MY_COMPONENT_CONTRACTID "@test.xyz/MyComponent;1"
#define MY_COMPONENT_CLASSNAME "XPCOM example"
#define MY_COMPONENT_CID { 0x8aec1ce8, 0x708e, 0x4285, { 0xab, 0xfd, 0x6e, 0xe9, 0x8d, 0xbf, 0x9d, 0x50 } }


class MyComponent : public IMyComponent
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_IMYCOMPONENT

  MyComponent();

private:
  ~MyComponent();
};

#endif
