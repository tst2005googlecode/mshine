-- Moonshine
-- Copyright (c) 2007-2008 Samuel Saint-Pettersen
--    
-- Lua
-- Copyright (C) 1994-2008 Lua.org, PUC-Rio
--
-- Released under the MIT License
--
-- Script to load and reference API modules for 
-- Moonshine's Lua interpreter

require("ui")
require("fuse")
