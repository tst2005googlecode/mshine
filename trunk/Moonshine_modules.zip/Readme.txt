Extract the folder 'lua' and its contents to C:\Program Files\Mozilla Firefox
