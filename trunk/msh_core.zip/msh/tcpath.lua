--------------------------
-- print package.cpath
--------------------------
print("package.cpath: " .. package.cpath)

