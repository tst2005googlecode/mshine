----------------------------------
-- greet the world
----------------------------------
print("Hello World!")
std.msg("Hello World!")

