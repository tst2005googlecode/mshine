print(net.version() .. "\n")
x = net.httpreq("http://www.something.com")
print(x)

